package com.example.carRental.dto;

public record CarResponseDTO(long id, String brand, String model, int year, String status) {


}
