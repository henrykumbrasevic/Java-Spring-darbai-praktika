package com.example.carRental.dto;

public record CarRequestDTO(String brand, String model, int year) {

}
